/********************************************************************************
** Form generated from reading UI file 'gameui.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMEUI_H
#define UI_GAMEUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gameUI
{
public:
    QWidget *centralwidget;
    QPushButton *saveBtn;
    QLabel *label_2;
    QPushButton *backBtn;
    QPushButton *nextBtn;

    void setupUi(QMainWindow *gameUI)
    {
        if (gameUI->objectName().isEmpty())
            gameUI->setObjectName(QStringLiteral("gameUI"));
        gameUI->resize(600, 420);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(gameUI->sizePolicy().hasHeightForWidth());
        gameUI->setSizePolicy(sizePolicy);
        gameUI->setMinimumSize(QSize(600, 420));
        gameUI->setMaximumSize(QSize(600, 420));
        QIcon icon;
        icon.addFile(QStringLiteral(":/reversi.ico"), QSize(), QIcon::Normal, QIcon::Off);
        gameUI->setWindowIcon(icon);
        gameUI->setAutoFillBackground(true);
        centralwidget = new QWidget(gameUI);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        saveBtn = new QPushButton(centralwidget);
        saveBtn->setObjectName(QStringLiteral("saveBtn"));
        saveBtn->setGeometry(QRect(500, 360, 81, 31));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(440, 60, 51, 31));
        backBtn = new QPushButton(centralwidget);
        backBtn->setObjectName(QStringLiteral("backBtn"));
        backBtn->setGeometry(QRect(430, 290, 71, 31));
        nextBtn = new QPushButton(centralwidget);
        nextBtn->setObjectName(QStringLiteral("nextBtn"));
        nextBtn->setGeometry(QRect(510, 290, 71, 31));
        gameUI->setCentralWidget(centralwidget);

        retranslateUi(gameUI);

        QMetaObject::connectSlotsByName(gameUI);
    } // setupUi

    void retranslateUi(QMainWindow *gameUI)
    {
        gameUI->setWindowTitle(QApplication::translate("gameUI", "Reversi (Othello)", 0));
#ifndef QT_NO_TOOLTIP
        saveBtn->setToolTip(QApplication::translate("gameUI", "Ulo\305\276\303\255 hru (S)", 0));
#endif // QT_NO_TOOLTIP
        saveBtn->setText(QApplication::translate("gameUI", "Ulo\305\276it", 0));
        saveBtn->setShortcut(QApplication::translate("gameUI", "S", 0));
        label_2->setText(QApplication::translate("gameUI", "<html><head/><body><p><span style=\" font-size:12pt;\">Sk\303\263re:</span></p></body></html>", 0));
#ifndef QT_NO_TOOLTIP
        backBtn->setToolTip(QApplication::translate("gameUI", "Vr\303\241t\303\255 se o tah zp\304\233t (B)", 0));
#endif // QT_NO_TOOLTIP
        backBtn->setText(QApplication::translate("gameUI", "Zp\304\233t", 0));
        backBtn->setShortcut(QApplication::translate("gameUI", "B", 0));
#ifndef QT_NO_TOOLTIP
        nextBtn->setToolTip(QApplication::translate("gameUI", "P\305\231esune se o tah dop\305\231edu (N)", 0));
#endif // QT_NO_TOOLTIP
        nextBtn->setText(QApplication::translate("gameUI", "Dop\305\231edu", 0));
        nextBtn->setShortcut(QApplication::translate("gameUI", "N", 0));
    } // retranslateUi

};

namespace Ui {
    class gameUI: public Ui_gameUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMEUI_H
