/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *newGB;
    QPushButton *newBtn;
    QComboBox *enemyCB;
    QComboBox *sizeCB;
    QLabel *sizeLabel;
    QLabel *enemyLabel;
    QGroupBox *loadGB;
    QLineEdit *loadArg;
    QPushButton *loadBtn;
    QPushButton *exitBtn;
    QPushButton *helpBtn;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(400, 307);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(400, 307));
        MainWindow->setMaximumSize(QSize(400, 307));
        QIcon icon;
        icon.addFile(QStringLiteral(":/reversi.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(true);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        newGB = new QGroupBox(centralWidget);
        newGB->setObjectName(QStringLiteral("newGB"));
        newGB->setGeometry(QRect(20, 20, 361, 121));
        newBtn = new QPushButton(newGB);
        newBtn->setObjectName(QStringLiteral("newBtn"));
        newBtn->setGeometry(QRect(140, 70, 75, 23));
        enemyCB = new QComboBox(newGB);
        enemyCB->setObjectName(QStringLiteral("enemyCB"));
        enemyCB->setGeometry(QRect(260, 30, 71, 22));
        sizeCB = new QComboBox(newGB);
        sizeCB->setObjectName(QStringLiteral("sizeCB"));
        sizeCB->setGeometry(QRect(90, 30, 69, 22));
        sizeLabel = new QLabel(newGB);
        sizeLabel->setObjectName(QStringLiteral("sizeLabel"));
        sizeLabel->setGeometry(QRect(20, 30, 61, 16));
        enemyLabel = new QLabel(newGB);
        enemyLabel->setObjectName(QStringLiteral("enemyLabel"));
        enemyLabel->setGeometry(QRect(180, 30, 71, 16));
        loadGB = new QGroupBox(centralWidget);
        loadGB->setObjectName(QStringLiteral("loadGB"));
        loadGB->setGeometry(QRect(20, 150, 361, 61));
        loadArg = new QLineEdit(loadGB);
        loadArg->setObjectName(QStringLiteral("loadArg"));
        loadArg->setGeometry(QRect(50, 20, 181, 20));
        loadArg->setMaxLength(64);
        loadBtn = new QPushButton(loadGB);
        loadBtn->setObjectName(QStringLiteral("loadBtn"));
        loadBtn->setEnabled(false);
        loadBtn->setGeometry(QRect(250, 20, 75, 23));
        exitBtn = new QPushButton(centralWidget);
        exitBtn->setObjectName(QStringLiteral("exitBtn"));
        exitBtn->setGeometry(QRect(160, 260, 75, 23));
        helpBtn = new QPushButton(centralWidget);
        helpBtn->setObjectName(QStringLiteral("helpBtn"));
        helpBtn->setGeometry(QRect(160, 220, 75, 23));
        MainWindow->setCentralWidget(centralWidget);
        loadGB->raise();
        newGB->raise();
        exitBtn->raise();
        helpBtn->raise();

        retranslateUi(MainWindow);

        enemyCB->setCurrentIndex(1);
        sizeCB->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Reversi (Othello)", 0));
        newGB->setTitle(QApplication::translate("MainWindow", "Vytvo\305\231en\303\255 hry", 0));
#ifndef QT_NO_TOOLTIP
        newBtn->setToolTip(QApplication::translate("MainWindow", "Vytvo\305\231\303\255 novou hru (C)", 0));
#endif // QT_NO_TOOLTIP
        newBtn->setText(QApplication::translate("MainWindow", "Nov\303\241 hra", 0));
        newBtn->setShortcut(QApplication::translate("MainWindow", "C", 0));
        enemyCB->clear();
        enemyCB->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "\304\214lov\304\233k", 0)
         << QApplication::translate("MainWindow", "Easy AI", 0)
         << QApplication::translate("MainWindow", "Hard AI", 0)
        );
#ifndef QT_NO_TOOLTIP
        enemyCB->setToolTip(QApplication::translate("MainWindow", "V\303\275b\304\233r typu protihr\303\241\304\215e", 0));
#endif // QT_NO_TOOLTIP
        sizeCB->clear();
        sizeCB->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "6x6", 0)
         << QApplication::translate("MainWindow", "8x8", 0)
         << QApplication::translate("MainWindow", "10x10", 0)
         << QApplication::translate("MainWindow", "12x12", 0)
        );
#ifndef QT_NO_TOOLTIP
        sizeCB->setToolTip(QApplication::translate("MainWindow", "V\303\275b\304\233r velikosti hry", 0));
#endif // QT_NO_TOOLTIP
        sizeLabel->setText(QApplication::translate("MainWindow", "Velikost", 0));
        enemyLabel->setText(QApplication::translate("MainWindow", "Protihr\303\241\304\215", 0));
        loadGB->setTitle(QApplication::translate("MainWindow", "Na\304\215ten\303\255 ulo\305\276en\303\251 hry", 0));
#ifndef QT_NO_TOOLTIP
        loadArg->setToolTip(QApplication::translate("MainWindow", "Zadejte n\303\241zev ulo\305\276en\303\251 hry", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_TOOLTIP
        loadBtn->setToolTip(QApplication::translate("MainWindow", "Na\304\215te ulo\305\276enou hru (L)", 0));
#endif // QT_NO_TOOLTIP
        loadBtn->setText(QApplication::translate("MainWindow", "Na\304\215\303\255st", 0));
        loadBtn->setShortcut(QApplication::translate("MainWindow", "L", 0));
#ifndef QT_NO_TOOLTIP
        exitBtn->setToolTip(QApplication::translate("MainWindow", "Ukon\304\215\303\255 hru (ESC)", 0));
#endif // QT_NO_TOOLTIP
        exitBtn->setText(QApplication::translate("MainWindow", "Konec", 0));
        exitBtn->setShortcut(QApplication::translate("MainWindow", "Esc", 0));
#ifndef QT_NO_TOOLTIP
        helpBtn->setToolTip(QApplication::translate("MainWindow", "Otev\305\231e n\303\241pov\304\233du (F1)", 0));
#endif // QT_NO_TOOLTIP
        helpBtn->setText(QApplication::translate("MainWindow", "N\303\241pov\304\233da", 0));
        helpBtn->setShortcut(QApplication::translate("MainWindow", "F1", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
